import React from 'react'

export default function Rings() {
  return (
    <div>Rings</div>
  )
}
