import React from "react";
import { CiHeart } from "react-icons/ci";

import { useSelector } from "react-redux";
export default function CartPage() {
  let cartData = useSelector((store) => store.cartSlice);
  console.log("===>cartData:", cartData);
  return (
    <div>
      <div className="flex min-h-screen items-center justify-center  px-20 py-[2rem] flex-col">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4 position-relative  ">
          {cartData?.cart?.map?.((item, index) => (
            <div
              key={index}
              className="relative group  cursor-pointer group overflow-hidden text-gray-50 border-black-500 border-[1px]   h-[20rem] w-[230px]  hover:duration-500 duration-700 hover:drop-shadow-lg"
            >
              <div className="">
                <img
                  src={item.thumbnail}
                  className="h-full   absolute object-fill transition-transform duration-500 group-hover:rotate-3   group-hover:scale-125 "
                />
                <p className="text-white text-md relative  inset-2   text-center bg-[#832729] w-12 ">
                  {item.discountPercentage}%
                </p>
                <span className="p-1 bg-white h-8 rounded-full drop-shadow-lg absolute top-2 right-2 w-8">
                  <CiHeart className="text-[#832729] text-2xl  " />
                </span>
              </div>
              <div className="absolute bg-[#fdf2f2c6] -bottom-[3rem] w-full  p-3  flex flex-col gap-1 group-hover:-bottom-0 group-hover:duration-600 duration-500">
                <span className="text-gray-800 font-bold text-xl capitalize">
                  {item.title}
                </span>
                <span className="flex gap-4 items-center">
                  <del className="text-neutral-600 text-md">₹ {item.price}</del>
                  <p className="text-black text-lg">
                    ₹
                    {Math.round(
                      item.price - (item.price * item.discountPercentage) / 100
                    )}
                  </p>
                </span>
                <button className=" border-[1px] border-black mt-2 px-3.5 font-com text-lg  capitalize text-black shadow hover:shadow-black/100 ">
                  Remove To Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
