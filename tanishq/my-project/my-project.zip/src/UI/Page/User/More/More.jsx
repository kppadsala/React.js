import React from 'react'

export default function More() {
  return (
    <div>More</div>
  )
}
