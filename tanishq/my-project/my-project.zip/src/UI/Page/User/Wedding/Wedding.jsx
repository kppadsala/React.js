import React from 'react'

export default function Wedding() {
  return (
    <div>Wedding</div>
  )
}
