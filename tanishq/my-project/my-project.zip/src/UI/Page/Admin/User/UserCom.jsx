import React from 'react'
import UserTable from './UserTable'

export default function UserCom() {
  return (
    <div>
      <UserTable/>
    </div>
  )
}
